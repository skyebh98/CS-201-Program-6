//Skye Hewitt
//sbhngh@mail.umkc.edu
//Program 6 - Recursive token game
// 04-28-19 

#include <iostream>

using namespace std;

//Function declaration
void tokenGame(int tokensGoal, int currTokens, int numTurns);

int main()
{
	int tokensGoal, numTurns, currTokens = 13;
	char playAgain = 'Y'; //"Yes"

	do
	{

		cout << "How many tokens would you like to reach? " << endl;
		cin >> tokensGoal;
		cout << "What is the number of turns? " << endl;
		cin >> numTurns;

		cout << "Seaching for solution within " << numTurns << " turn(s)... " << endl;

		tokenGame(tokensGoal, currTokens, numTurns);

		do //Play again
		{

			cout << endl << "Would you like to play again? (Y/N) " << endl;
			cin >> playAgain;

		} while (playAgain != 'n' && playAgain != 'N' && playAgain != 'y' && playAgain != 'Y');

	} while (playAgain != 'n' && playAgain != 'N'); 


	cout << endl << "Thanks for playing! " << endl;

	return 0;
}

//Function definition
void tokenGame(int tokensGoal, int currTokens, int numTurns)
{
	if (numTurns == 0 && currTokens != tokensGoal) //Base case 1
		cout << "Token goal not reached within alloted turns! " << endl;
	else if (currTokens == tokensGoal) //Base case 2
		cout << "Token goal reached with (" << numTurns << ") remaining. " << endl;
	else if (currTokens % 2 == 0)
	{
		currTokens /= 2;
		cout << "Reducing by half, you get " << currTokens << " tokens. " << endl;
		tokenGame(tokensGoal, currTokens, numTurns - 1);
	}
	else
	{
		currTokens += 25;
		cout << "Adding 25, you get " << currTokens << " tokens. " << endl;
		tokenGame(tokensGoal, currTokens, numTurns - 1);
	}

}
